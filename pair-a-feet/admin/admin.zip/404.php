<!DOCTYPE html>
<html>
    <!-- Mirrored from themesdesign.in/xadmino/pages-404.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 19 Jul 2020 14:55:49 GMT -->
    <head>
        <meta charset="utf-8" />
        <title>404 Page Not Found</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta content="Admin Dashboard" name="description" />
        <meta content="ThemeDesign" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="shortcut icon" href="assets/images/favicon.ico" />
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/style.css" rel="stylesheet" type="text/css" />

    </head>
    <body>
        <div class="accountbg"></div>
        <div class="wrapper-page">
            <div class="ex-page-content text-center">
                <h1 class="text-white">404!</h1>
                <h2 class="text-white">Sorry, page not found</h2>
                <br />
                <a class="btn btn-primary waves-effect waves-light" href="dashboard.php">Back to Dashboard</a>
            </div>
        </div>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/modernizr.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/js/app.js"></script>
    </body>
    <!-- Mirrored from themesdesign.in/xadmino/pages-404.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 19 Jul 2020 14:55:49 GMT -->
</html>
